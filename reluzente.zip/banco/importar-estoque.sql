-- Importação da planilha de controle de pratas
insert into products(code,name,category,price,qty) values
('PU01','Pulseira laço cravejado','Pulseira',99.90,1),
('PU02','Pulseira elo meio cravejado','Pulseira',99.90,1),
('PU03','Pulseira mão de Fátima','Pulseira',59.90,1),
('PU04','Pulseira elo de corações P','Pulseira',59.90,1),
('PU05','Pulseira coração colorido','Pulseira',89.90,1),
('PU06','Pulseira patinha','Pulseira',69.90,1),
('PU07','Pulseira elo','Pulseira',49.90,1),
('PU08','Pulseira lótus','Pulseira',69.90,1),
('PU09','Pulseira infantil 3 zircônias','Pulseira',59.90,1),
('PU10','Pulseira Virgínia','Pulseira',79.90,1),
('PU11','Pulseira trevo','Pulseira',59.90,1),
('PU12','Pulseira infantil 3 bolinhas','Pulseira',59.90,1),
('PU13','Pulseira elo de coração M','Pulseira',59.90,1),
('PI01','Piercing estrela','Piercing',39.90,1),
('PI02','Piercing raio','Piercing',39.90,1),
('PI03','Piercing argola','Piercing',59.90,1),
('BC01','Brinco cartilagem flores','Brinco cartilagem',59.90,1),
('BC02','Brinco cartilagem argola','Brinco cartilagem',89.90,1),
('C01','Conjunto coração','Conjunto',169.90,1),
('C02','Conjunto cruz cravejado','Conjunto',139.90,1),
('C03','Conjunto zircônia verde','Conjunto',149.90,1),
('C04','Conjunto laço cravejado','Conjunto',149.90,1),
('C05','Conjunto cravejado','Conjunto',139.90,1),
('C06','Conjunto envelhecido','Conjunto',179.90,1),
('BR01','Brinco ponto de luz 5mm','Brinco',39.90,2),
('BR02','Brinco ponto de luz 2mm','Brinco',19.90,7),
('BR03','Brinco redondo','Brinco',69.90,1),
('BR04','Brinco flor','Brinco',69.90,1),
('BR05','Brinco mini infinito','Brinco',39.90,1),
('BR06','Brinco rosa','Brinco',49.90,1),
('BR07','Brinco coração asas','Brinco',49.90,1),
('BR08','Brinco encaixe infinito','Brinco',69.90,1),
('BR09','Brinco ramo','Brinco',49.90,1),
('BR10','Brinco importado','Brinco',89.90,1),
('BR11','Brinco flor redondo','Brinco',59.90,1),
('BR12','Brinco coração asa','Brinco',79.90,1),
('BR13','Brinco cravejado X','Brinco',89.90,1),
('BR14','Brinco laço cravejado','Brinco',64.90,1),
('BR15','Brinco asas','Brinco',39.90,1),
('BR16','Brinco floco de neve','Brinco',59.90,1),
('BR17','Brinco coração vazado','Brinco',59.90,1),
('BR18','Brinco flor (modelo 2)','Brinco',39.90,1),
('BR19','Brinco 3 zircônias','Brinco',69.90,1),
('BR20','Brinco libélula','Brinco',69.90,1),
('BR21','Brinco coração chapa','Brinco',39.90,1),
('BR22','Brinco Grécia','Brinco',69.90,1),
('BR23','Brinco coração vazado G','Brinco',74.90,1),
('BR24','Brinco Austrália','Brinco',59.90,1),
('BR25','Brinco ponto azul','Brinco',69.90,1),
('AC01','Argola cartilagem','Argola cartilagem',39.90,1),
('AC02','Argola cartilagem fake','Argola cartilagem',59.90,1),
('BE01','Berloque bolsa','Berloque',89.90,1),
('BE02','Berloque alicate','Berloque',79.90,1),
('BE03','Berloque tesoura','Berloque',49.99,1),
('BE04','Berloque anjo','Berloque',69.90,1),
('BE05','Berloque passaporte','Berloque',69.90,2),
('BE06','Berloque cruz','Berloque',59.90,1),
('BE07','Berloque cachorro','Berloque',69.90,1),
('BE08','Berloque administração','Berloque',59.90,2),
('BE09','Berloque avião','Berloque',79.90,1),
('BE10','Berloque laço','Berloque',55.90,1),
('BE11','Berloque pata','Berloque',69.90,1),
('BE12','Berloque coração trançado','Berloque',79.90,1),
('BE13','Berloque corrida','Berloque',89.90,1),
('BE14','Berloque coração pequeno','Berloque',49.90,1),
('BE15','Berloque direito','Berloque',49.90,1),
('BE16','Berloque Corinthians','Berloque',89.90,1),
('BE17','Berloque algemas','Berloque',64.90,1),
('BE18','Berloque Goiás','Berloque',89.90,1),
('BE19','Berloque enfermagem','Berloque',49.90,1),
('BE20','Berloque Espírito Santo','Berloque',79.90,1),
('BE21','Berloque Nossa Senhora','Berloque',79.90,1),
('BE22','Berloque ferradura','Berloque',54.90,1),
('BE23','Berloque separador','Berloque',49.90,1),
('BE24','Berloque libélula','Berloque',49.90,1),
('AN26','Anel número 14','Anel',119.90,0),
('AN13','Anel número 19','Anel',109.90,1),
('AN22','Anel número 10','Anel',79.90,1),
('AN20','Anel número 14','Anel',79.90,1),
('AN21','Anel número 21','Anel',69.90,1),
('AN31','Anel número 19','Anel',89.90,1),
('AN27','Anel número 15','Anel',119.90,0),
('AN24','Anel número 12','Anel',79.90,1),
('AN28','Anel número 15','Anel',89.90,0),
('AN40','Anel número 11','Anel',79.90,1),
('AN29','Anel número 16','Anel',89.90,1),
('AN05','Anel número 21','Anel',89.90,1),
('AN15','Anel número 20','Anel',89.90,1),
('AN17','Anel número 21','Anel',89.90,1),
('AN01','Anel número 14','Anel',89.90,1),
('AN07','Anel número 14','Anel',99.90,1),
('AN18','Anel número 19','Anel',89.90,1),
('AN36','Anel número 17','Anel',119.90,1),
('AN06','Anel número 13','Anel',69.90,1),
('AN04','Anel número 19','Anel',109.90,1),
('AN12','Anel número 17','Anel',109.90,1),
('AN37','Anel número 11','Anel',79.90,1),
('AN30','Anel número 18','Anel',89.90,1),
('AN09','Anel número 21','Anel',109.90,1),
('AN38','Anel número 19','Anel',89.90,1),
('AN42','Anel número 12','Anel',69.90,1),
('AN03','Anel número 11','Anel',109.90,1),
('AN39','Anel número 17','Anel',89.90,1),
('AN32','Anel número 15','Anel',69.90,1),
('AN08','Anel número 13','Anel',39.90,1),
('AN45','Anel regulável','Anel',59.90,1),
('AN35','Anel número 15','Anel',79.90,1),
('AN19','Anel número 20','Anel',89.90,1),
('AN46','Anel número 16','Anel',79.90,1),
('AN33','Anel número 14','Anel',79.90,1),
('AN11','Anel número 16','Anel',79.90,1),
('AN02','Anel número 17','Anel',89.90,1),
('AN10','Anel número 17','Anel',79.90,1),
('BR26','Brinco estrelar','Brinco',79.90,1),
('BR27','Brinco patinha cravejada','Brinco',59.90,1),
('BR28','Brinco corrente ponto de luz','Brinco',59.90,2),
('BR29','Brinco argola','Brinco',69.90,1),
('BR30','Brinco ramo','Brinco',59.90,1),
('BR31','Brinco orgânico','Brinco',79.90,1),
('BR32','Brinco coração azul','Brinco',69.90,1),
('BR33','Brinco coração esmeralda','Brinco',69.90,1),
('BR34','Brinco coração vazado','Brinco',69.90,1),
('BR35','Brinco 7mm esmeralda','Brinco',29.90,2),
('BR36','Brinco 6mm azul bic','Brinco',24.90,1),
('BR37','Brinco 7mm rubi','Brinco',29.90,1),
('BR38','Brinco 5mm cristal','Brinco',24.90,1),
('BR39','Brinco coração cristal','Brinco',29.90,1),
('BR40','Brinco coração cristal 6mm','Brinco',24.90,1),
('BR41','Brinco coração rubelita 6mm','Brinco',24.90,1),
('BR42','Brinco carré cristal 6mm','Brinco',24.90,1),
('BR43','Brinco carré cristal 8mm','Brinco',34.90,1),
('BR44','Brinco carré cristal 7mm','Brinco',29.90,1),
('BR45','Brinco zircônia cristal 8mm','Brinco',49.90,1),
('BR46','Brinco zircônia cristal 12mm','Brinco',69.90,1),
('TR01','Trio 3,4,5mm','Trio',69.90,3),
('TR02','Trio turmalina','Trio',69.90,1),
('TR03','Trio rosa','Trio',69.90,1),
('TR04','Trio 4,5,6mm','Trio',79.90,1),
('PI04','Piercing estrela','Piercing',49.90,1),
('PI05','Piercing curvado','Piercing',39.90,1),
('AR01','Argola com pena','Argola',59.90,1),
('PM01','Pulseira GMT masculina 2mm','Pulseira',99.90,1),
('PM02','Pulseira GMT masculina 1mm','Pulseira',89.90,2),
('PM03','Pulseira 1x1 GMT masculina','Pulseira',119.90,1),
('CR01','Corrente GMT masculina','Corrente',189.90,1),
('CR02','Corrente Cartier masculina','Corrente',209.90,1),
('ES01','Escapulário Cartier','Escapulário',159.90,2),
('ES02','Escapulário Deus','Escapulário',234.90,1),
('CO01','Colar pingo de luz','Colar',79.90,3),
('CO02','Colar letra E cravejada','Colar',109.90,2),
('CO03','Colar letra R cravejado','Colar',109.90,1),
('CO04','Colar letra M cravejado','Colar',109.90,1),
('CO05','Colar letra B cravejada','Colar',109.90,1),
('CO06','Colar letra S cravejada','Colar',109.90,1),
('CO07','Colar letra C cravejada','Colar',109.90,1),
('CO08','Colar letra F cravejada','Colar',109.90,1),
('CO09','Colar letra K cravejada','Colar',109.90,1),
('CO10','Colar letra E','Colar',109.90,1),
('CO11','Colar letra K','Colar',109.90,1),
('CO12','Colar letra G','Colar',109.90,1),
('CO13','Colar letra fina B','Colar',109.90,1),
('CO14','Colar letra fina D','Colar',109.90,1),
('CO15','Colar letra fina N','Colar',109.90,1),
('CO16','Colar letra fina C','Colar',109.90,1),
('CO17','Colar filha G','Colar',119.90,2),
('CO18','Colar duas filhas em um','Colar',119.90,1),
('CO19','Colar um filho','Colar',119.90,1),
('CO20','Colar um filho prata azul','Colar',119.90,1),
('CO21','Colar um filho prata cristal','Colar',119.90,1),
('CO22','Colar uma filha rosa','Colar',119.90,2),
('CO23','Colar uma filha prata cristal','Colar',119.90,2),
('CO24','Colar infantil abelha','Colar',109.90,1),
('CO25','Colar infantil uva cristal','Colar',109.90,1),
('CO26','Colar infantil uva colorido','Colar',109.90,1),
('CO27','Colar infantil borboleta colorida','Colar',109.90,1),
('CO28','Colar infantil unicórnio','Colar',109.90,1),
('CO29','Colar árvore da vida','Colar',119.90,1),
('CO30','Colar 2 corações','Colar',119.90,1),
('CO31','Colar coração mais pezinho','Colar',119.90,1),
('CO32','Colar coração liso mais cravejado','Colar',119.90,1),
('CO33','Colar coração mini cruz','Colar',119.90,1),
('CO34','Colar mão judaica','Colar',119.90,1),
('CO35','Colar cruz cravejada','Colar',119.90,1),
('CO36','Colar coração + patinha','Colar',119.90,1),
('CO37','Colar coração entre elos','Colar',119.90,1),
('CO38','Colar mini cruz cravejado','Colar',119.90,1),
('CO39','Colar coração + cruz','Colar',119.90,1),
('CO40','Colar cruz cravejado','Colar',119.90,0),
('CO41','Colar coração vazado + mini','Colar',119.90,1),
('CO42','Colar cruz colorida','Colar',129.90,1),
('CO43','Colar cruz cravejada cristal','Colar',129.90,1),
('CO44','Colar redondo Jesus','Colar',129.90,1),
('CO45','Colar 2 corações cravejado','Colar',119.90,1),
('CO46','Colar mini coração','Colar',119.90,1),
('CO47','Colar coração vazado','Colar',109.90,1),
('CO48','Colar medicina','Colar',149.90,1),
('CO49','Colar Nossa Senhora Aparecida','Colar',119.90,1),
('CO50','Colar Nossa Senhora Aparecida envelhecida','Colar',119.90,1),
('CO51','Colar pérola','Colar',149.90,1),
('CO52','Colar ferradura','Colar',129.90,1),
('CO53','Colar chapéu','Colar',129.90,1),
('CO54','Colar cristal liso','Colar',129.90,2),
('CO55','Colar coração rubelita cravejado','Colar',129.90,1),
('CO56','Colar oval rosa claro','Colar',119.90,1),
('CO57','Colar gota rubi','Colar',129.90,1),
('CO58','Colar gota ônix','Colar',129.90,1),
('C08','Conjunto folha cravejado','Conjunto',179.90,1),
('PIM01','Pingente masculino Jesus','Pingente masculino',69.90,1),
('PIM02','Pingente masculino São José','Pingente masculino',69.90,1),
('PIM03','Pingente masculino Cruz','Pingente masculino',69.90,1),
('BR47','Brinco mini infinito','Brinco',39.90,1),
('BR48','Brinco ramo cravejado','Brinco',59.90,1),
('C08-NOVO','Conjunto gota azul bic','Conjunto',149.90,1),
('C09','Conjunto redondo azul bic','Conjunto',149.90,1),
('C10','Conjunto redondo rosa bebê','Conjunto',149.90,1),
('C11','Conjunto redondo pink','Conjunto',149.90,1),
('C12','Conjunto importado cravejado','Conjunto',199.90,1),
('RE01','Relógio oval prata / branco','Relógio',119.90,1),
('RE02','Relógio oval prata / preto','Relógio',119.90,1),
('RE03','Relógio oval todo preto','Relógio',119.90,1),
('RE04','Relógio quadrado todo preto','Relógio',119.90,1),
('RE05','Relógio quadrado rosa','Relógio',119.90,1),
('RE06','Relógio quadrado masculino','Relógio',119.90,1),
('OC01','Óculos (lote de 26 unidades)','Óculos',100.00,26),
('C13','Conjunto gota rosa bebê','Conjunto',149.90,1),
('AN47','Anel 8 mm n15','Anel',109.90,1),
('AN48','Anel 8mm n17','Anel',109.90,1),
('AN49','Anel 8 mm n18','Anel',109.90,1)
on conflict (code) do nothing;
-- Estoque inicial
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU05';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU06';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU07';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU08';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU09';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU10';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU11';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU12';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PU13';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PI01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PI02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PI03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BC01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BC02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C05';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C06';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',3,'Estoque inicial (planilha)','2026-10-01' from products where code='BR01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',7,'Estoque inicial (planilha)','2026-10-01' from products where code='BR02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR05';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR06';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR07';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR08';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR09';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR10';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR11';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR12';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR13';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR14';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR15';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR16';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR17';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR18';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR19';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR20';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR21';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR22';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR23';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR24';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR25';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AC01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AC02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='BE05';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE06';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE07';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='BE08';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE09';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE10';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE11';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE12';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE13';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE14';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE15';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE16';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE17';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE18';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE19';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE20';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE21';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE22';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE23';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BE24';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN26';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN13';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN22';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN20';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN21';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN31';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN27';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN24';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN28';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN40';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN29';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN05';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN15';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN17';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN07';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN18';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN36';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN06';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN12';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN37';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN30';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN09';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN38';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN42';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN39';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN32';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN08';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN45';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN35';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN19';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN46';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN33';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN11';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN10';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR26';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR27';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='BR28';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR29';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR30';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR31';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR32';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR33';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR34';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='BR35';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR36';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR37';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR38';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR39';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR40';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR41';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR42';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR43';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR44';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR45';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR46';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',3,'Estoque inicial (planilha)','2026-10-01' from products where code='TR01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='TR02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='TR03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='TR04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PI04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PI05';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AR01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PM01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='PM02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PM03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CR01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CR02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='ES01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='ES02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',3,'Estoque inicial (planilha)','2026-10-01' from products where code='CO01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='CO02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO05';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO06';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO07';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO08';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO09';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO10';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO11';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO12';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO13';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO14';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO15';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO16';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='CO17';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO18';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO19';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO20';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO21';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='CO22';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='CO23';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO24';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO25';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO26';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO27';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO28';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO29';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO30';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO31';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO32';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO33';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO34';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO35';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO36';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO37';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO38';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO39';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO40';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO41';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO42';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO43';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO44';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO45';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO46';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO47';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO48';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO49';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO50';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO51';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO52';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO53';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',2,'Estoque inicial (planilha)','2026-10-01' from products where code='CO54';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO55';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO56';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO57';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='CO58';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C08';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PIM01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PIM02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='PIM03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR47';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='BR48';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C08-NOVO';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C09';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C10';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C11';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C12';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='RE01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='RE02';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='RE03';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='RE04';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='RE05';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='RE06';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',26,'Estoque inicial (planilha)','2026-10-01' from products where code='OC01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='C13';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN47';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN48';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'entrada',1,'Estoque inicial (planilha)','2026-10-01' from products where code='AN49';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'baixa',1,'Planilha','2026-10-31' from products where code='AN28';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'baixa',1,'Planilha','2026-11-02' from products where code='CO40';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'baixa',1,'Planilha','2026-11-02' from products where code='AN26';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'baixa',1,'Planilha','2026-11-02' from products where code='BR01';
insert into stock_moves(product_id,type,qty,note,created_at) select id,'baixa',1,'Planilha','2026-11-02' from products where code='AN27';
