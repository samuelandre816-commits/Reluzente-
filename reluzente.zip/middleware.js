import { NextResponse } from 'next/server';
import { jwtVerify } from 'jose';
export async function middleware(req) {
  const p = req.nextUrl.pathname;
  if (p === '/login' || p === '/setup') return NextResponse.next();
  try {
    await jwtVerify(req.cookies.get('rlz')?.value, new TextEncoder().encode(process.env.AUTH_SECRET));
    return NextResponse.next();
  } catch {
    return NextResponse.redirect(new URL('/login', req.url));
  }
}
export const config = { matcher: ['/((?!_next|favicon.ico).*)'] };
