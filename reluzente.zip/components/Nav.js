'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
export default function Nav({ items }) {
  const p = usePathname();
  return (<nav className="nav">{items.map(([h, l]) => (<Link key={h} href={h} className={p.startsWith(h) ? 'on' : ''}>{l}</Link>))}</nav>);
}
