import { redirect } from 'next/navigation';
import { sql } from '@/lib/db';
import { setup } from '../login/actions';
export const dynamic = 'force-dynamic';
export default async function Setup({ searchParams }) {
  const [{ n }] = await sql`select count(*)::int n from users`;
  if (n > 0) redirect('/login');
  return (
    <main className="center"><form action={setup} className="box">
      <div className="logo grad">RELUZENTE</div>
      <p className="mut">Primeiro acesso: crie o usuário administrador.</p>
      <label>Nome<input name="name" required /></label>
      <label>E-mail<input name="email" type="email" required /></label>
      <label>Senha (mínimo 8 caracteres)<input name="password" type="password" minLength={8} required /></label>
      {searchParams.erro && <p className="err">Confira os dados (senha com 8+ caracteres).</p>}
      <button className="btn">Criar acesso</button>
    </form></main>
  );
}
