import { Cinzel, Cinzel_Decorative, Inter } from 'next/font/google';
import './globals.css';
const cz = Cinzel({ subsets: ['latin'], variable: '--f-cz' });
const cd = Cinzel_Decorative({ subsets: ['latin'], weight: ['400', '700'], variable: '--f-cd' });
const it = Inter({ subsets: ['latin'], variable: '--f-in' });
export const metadata = { title: 'Reluzente', description: 'Gestão da loja Reluzente' };
export default function Root({ children }) {
  return (<html lang="pt-BR" className={`${cz.variable} ${cd.variable} ${it.variable}`}><body>{children}</body></html>);
}
