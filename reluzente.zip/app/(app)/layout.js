import Nav from '@/components/Nav';
import { requireUser } from '@/lib/auth';
import { logout } from '../login/actions';
export const dynamic = 'force-dynamic';
export default async function AppLayout({ children }) {
  const u = await requireUser();
  const adm = u.role === 'admin';
  const items = [['/dashboard', 'Dashboard'], ['/clientes', 'Clientes'], ['/estoque', 'Estoque'], ['/vendas', 'Vendas'], ...(adm ? [['/financeiro', 'Financeiro'], ['/usuarios', 'Usuários']] : [])];
  return (
    <div className="shell">
      <aside className="side">
        <div className="logo grad">RELUZENTE</div>
        <div className="who"><b>{u.name}</b><span>{adm ? 'Administrador' : 'Vendedor'}</span></div>
        <Nav items={items} />
        <form action={logout}><button className="out">Sair</button></form>
      </aside>
      <section className="content">{children}</section>
    </div>
  );
}
