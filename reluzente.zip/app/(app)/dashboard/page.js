import { sql } from '@/lib/db';
import { money, dt } from '@/lib/fmt';
export default async function Dashboard() {
  const [k] = await sql`select coalesce(sum(qty),0)::int pcs, coalesce(sum(qty*price),0) val from products where active`;
  const [m] = await sql`select coalesce(sum(total),0) fat, count(*)::int n from sales where status='ativa' and created_at >= date_trunc('month', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'`;
  const [v] = await sql`select coalesce(sum(i.qty),0)::int pcs from sale_items i join sales s on s.id=i.sale_id where s.status='ativa' and s.created_at >= date_trunc('month', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'`;
  const out = await sql`select code, name from products where active and qty=0 order by code limit 8`;
  const last = await sql`select number, total, payment, created_at from sales where status='ativa' order by created_at desc limit 5`;
  const kp = [['Peças em estoque', k.pcs], ['Valor em estoque', money(k.val)], ['Vendas no mês', money(m.fat)], ['Peças vendidas no mês', v.pcs]];
  return (<>
    <h1 className="grad">Dashboard</h1>
    <div className="grid">{kp.map(([a, b]) => (<div className="card kpi" key={a}><span>{a}</span><b className="grad">{b}</b></div>))}</div>
    <div className="two">
      <div className="card"><h2>Últimas vendas</h2>{last.length ? (<table><tbody>{last.map((s) => (<tr key={s.number}><td>#{String(s.number).padStart(4, '0')}</td><td>{dt(s.created_at)}</td><td className="n">{money(s.total)}</td></tr>))}</tbody></table>) : <p className="mut">Nenhuma venda ainda.</p>}</div>
      <div className="card"><h2>Esgotados</h2>{out.length ? (<table><tbody>{out.map((p) => (<tr key={p.code}><td>{p.code}</td><td>{p.name}</td></tr>))}</tbody></table>) : <p className="mut">Nenhuma peça esgotada.</p>}</div>
    </div>
  </>);
}
