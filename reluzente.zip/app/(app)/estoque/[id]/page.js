import Link from 'next/link';
import { notFound } from 'next/navigation';
import { sql } from '@/lib/db';
import { dt } from '@/lib/fmt';
import { updateProduct } from '../actions';
export default async function Editar({ params }) {
  const [p] = await sql`select * from products where id=${params.id}`;
  if (!p) notFound();
  const mv = await sql`select * from stock_moves where product_id=${p.id} order by created_at desc limit 20`;
  return (<>
    <h1 className="grad">{p.code}</h1>
    <div className="card"><form action={updateProduct} className="fgrid"><input type="hidden" name="id" value={p.id} />
      <label>Nome<input name="name" defaultValue={p.name} required /></label><label>Categoria<input name="category" defaultValue={p.category} /></label>
      <label>Preço de venda<input name="price" inputMode="decimal" defaultValue={p.price} /></label><label>Custo<input name="cost" inputMode="decimal" defaultValue={p.cost} /></label>
      <label className="chk"><input type="checkbox" name="active" defaultChecked={p.active} /> Peça ativa</label>
      <button className="btn">Salvar</button></form></div>
    <div className="card" style={{ marginTop: 14 }}><h2>Movimentações</h2><table><tbody>{mv.map((m) => (<tr key={m.id}><td>{dt(m.created_at)}</td><td><span className="tag">{m.type}</span></td><td className="n">{m.qty}</td><td>{m.note}</td></tr>))}</tbody></table></div>
    <p><Link className="lnk" href="/estoque">← Voltar ao estoque</Link></p>
  </>);
}
