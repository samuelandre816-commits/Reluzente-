'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { sql } from '@/lib/db';
import { requireUser } from '@/lib/auth';
import { num } from '@/lib/fmt';
const back = (m, to = '/estoque') => { revalidatePath('/estoque'); redirect(`${to}?msg=${encodeURIComponent(m)}`); };
const code = (fd) => String(fd.get('code') || '').trim().toUpperCase();
const byCode = async (c) => (await sql`select * from products where code=${c}`)[0];
export async function createProduct(fd) {
  await requireUser();
  const c = code(fd), name = String(fd.get('name') || '').trim(), q = Math.max(0, parseInt(fd.get('qty')) || 0);
  if (!c || !name) back('Informe código e nome.');
  if (await byCode(c)) back(`O código ${c} já existe.`);
  const [p] = await sql`insert into products(code,name,category,price,cost,qty) values(${c},${name},${String(fd.get('category') || '').trim()},${num(fd.get('price'))},${num(fd.get('cost'))},${q}) returning id`;
  if (q) await sql`insert into stock_moves(product_id,type,qty,unit_cost,note) values(${p.id},'entrada',${q},${num(fd.get('cost'))},'Estoque inicial')`;
  back(`Peça ${c} cadastrada.`);
}
export async function addEntry(fd) {
  await requireUser();
  const p = await byCode(code(fd)), q = parseInt(fd.get('qty')) || 0, cost = num(fd.get('cost'));
  if (!p || q < 1) back('Código não encontrado ou quantidade inválida.');
  await sql.transaction([
    sql`update products set qty=qty+${q}, cost=case when ${cost}>0 then ${cost} else cost end where id=${p.id}`,
    sql`insert into stock_moves(product_id,type,qty,unit_cost,note) values(${p.id},'entrada',${q},${cost},${String(fd.get('note') || '')})`,
  ]);
  back(`Entrada registrada: ${q} × ${p.code}.`);
}
export async function addExit(fd) {
  await requireUser();
  const p = await byCode(code(fd)), q = parseInt(fd.get('qty')) || 0;
  if (!p || q < 1 || q > p.qty) back('Código não encontrado ou quantidade maior que o estoque.');
  await sql.transaction([
    sql`update products set qty=qty-${q} where id=${p.id}`,
    sql`insert into stock_moves(product_id,type,qty,note) values(${p.id},'baixa',${q},${String(fd.get('note') || '')})`,
  ]);
  back(`Baixa registrada: ${q} × ${p.code}.`);
}
export async function updateProduct(fd) {
  await requireUser();
  const id = String(fd.get('id'));
  await sql`update products set name=${String(fd.get('name')).trim()}, category=${String(fd.get('category') || '').trim()}, price=${num(fd.get('price'))}, cost=${num(fd.get('cost'))}, active=${fd.get('active') === 'on'} where id=${id}`;
  back('Peça atualizada.');
}
