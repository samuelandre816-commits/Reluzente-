import Link from 'next/link';
import { sql } from '@/lib/db';
import { money } from '@/lib/fmt';
import { createProduct, addEntry, addExit } from './actions';
export default async function Estoque({ searchParams }) {
  const q = `%${searchParams.q || ''}%`, cat = searchParams.cat || '';
  const rows = await sql`select p.*, coalesce((select sum(i.qty) from sale_items i join sales s on s.id=i.sale_id where i.product_id=p.id and s.status='ativa'),0)::int sold from products p where p.active and (p.name ilike ${q} or p.code ilike ${q}) and (${cat}='' or p.category=${cat}) order by p.category, p.code`;
  const cats = await sql`select distinct category from products where category<>'' order by 1`;
  const tot = rows.reduce((a, p) => a + p.qty, 0);
  return (<>
    <h1 className="grad">Estoque</h1>
    {searchParams.msg && <p className="ok">{searchParams.msg}</p>}
    <datalist id="cats">{cats.map((c) => <option key={c.category} value={c.category} />)}</datalist>
    <datalist id="codes">{rows.map((p) => <option key={p.id} value={p.code}>{p.name}</option>)}</datalist>
    <div className="tools">
      <details className="card"><summary>+ Nova peça</summary><form action={createProduct} className="fgrid">
        <label>Código<input name="code" required /></label><label>Nome<input name="name" required /></label>
        <label>Categoria<input name="category" list="cats" /></label><label>Preço de venda<input name="price" inputMode="decimal" /></label>
        <label>Custo<input name="cost" inputMode="decimal" /></label><label>Qtd inicial<input name="qty" type="number" min="0" defaultValue="0" /></label>
        <button className="btn">Cadastrar</button></form></details>
      <details className="card"><summary>Dar entrada</summary><form action={addEntry} className="fgrid">
        <label>Código<input name="code" list="codes" required /></label><label>Quantidade<input name="qty" type="number" min="1" defaultValue="1" /></label>
        <label>Custo unitário<input name="cost" inputMode="decimal" /></label><label>Observação<input name="note" /></label>
        <button className="btn">Registrar entrada</button></form></details>
      <details className="card"><summary>Dar baixa (sem venda)</summary><form action={addExit} className="fgrid">
        <label>Código<input name="code" list="codes" required /></label><label>Quantidade<input name="qty" type="number" min="1" defaultValue="1" /></label>
        <label>Motivo<input name="note" placeholder="Defeito, presente…" /></label>
        <button className="btn">Registrar baixa</button></form></details>
    </div>
    <form className="filters"><input name="q" placeholder="Buscar por código ou nome" defaultValue={searchParams.q || ''} />
      <select name="cat" defaultValue={cat}><option value="">Todas as categorias</option>{cats.map((c) => <option key={c.category}>{c.category}</option>)}</select>
      <button className="btn o">Filtrar</button></form>
    <p className="mut">{rows.length} produtos · {tot} peças</p>
    <div className="card wrap"><table><thead><tr><th>Código</th><th>Produto</th><th>Categoria</th><th className="n">Preço</th><th className="n">Custo</th><th className="n">Estoque</th><th className="n">Vendidos</th><th></th></tr></thead>
      <tbody>{rows.map((p) => (<tr key={p.id}><td>{p.code}</td><td>{p.name}</td><td>{p.category}</td><td className="n">{money(p.price)}</td><td className="n">{Number(p.cost) ? money(p.cost) : '—'}</td>
        <td className="n"><span className={`tag ${p.qty === 0 ? 'low' : ''}`}>{p.qty}</span></td><td className="n">{p.sold}</td><td className="n"><Link className="lnk" href={`/estoque/${p.id}`}>Editar</Link></td></tr>))}</tbody></table></div>
  </>);
}
