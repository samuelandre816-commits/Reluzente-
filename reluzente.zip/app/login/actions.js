'use server';
import bcrypt from 'bcryptjs';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { sql } from '@/lib/db';
import { createSession } from '@/lib/auth';
export async function login(fd) {
  const email = String(fd.get('email') || '').trim().toLowerCase();
  const pw = String(fd.get('password') || '');
  const [u] = await sql`select * from users where email=${email} and active`;
  if (!u || !(await bcrypt.compare(pw, u.password_hash))) redirect('/login?erro=1');
  await createSession(u);
  redirect('/dashboard');
}
export async function setup(fd) {
  const [{ n }] = await sql`select count(*)::int n from users`;
  if (n > 0) redirect('/login');
  const name = String(fd.get('name') || '').trim();
  const email = String(fd.get('email') || '').trim().toLowerCase();
  const pw = String(fd.get('password') || '');
  if (!name || !email || pw.length < 8) redirect('/setup?erro=1');
  const h = await bcrypt.hash(pw, 10);
  const [u] = await sql`insert into users(name,email,password_hash,role) values(${name},${email},${h},'admin') returning *`;
  await createSession(u);
  redirect('/dashboard');
}
export async function logout() {
  cookies().delete('rlz');
  redirect('/login');
}
