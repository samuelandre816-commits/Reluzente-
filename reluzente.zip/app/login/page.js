import { redirect } from 'next/navigation';
import { sql } from '@/lib/db';
import { login } from './actions';
export const dynamic = 'force-dynamic';
export default async function Login({ searchParams }) {
  const [{ n }] = await sql`select count(*)::int n from users`;
  if (!n) redirect('/setup');
  return (
    <main className="center"><form action={login} className="box">
      <div className="logo grad">RELUZENTE</div>
      <label>E-mail<input name="email" type="email" required autoFocus /></label>
      <label>Senha<input name="password" type="password" required /></label>
      {searchParams.erro && <p className="err">E-mail ou senha incorretos.</p>}
      <button className="btn">Entrar</button>
    </form></main>
  );
}
